package tut3.Ex2;

public class NotFoundException extends Exception {
    public NotFoundException(String message) {
        super(message);
    }
}
