package tut3.Ex2;

public class NonPositiveException extends Exception{
    public NonPositiveException(String str) {
        super(str);
    }
}
