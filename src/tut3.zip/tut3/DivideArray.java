package Tut3;

public class DivideArray {
    public static void main(String[] args) {
        int[] array = new int[]{12, 3, 4, 5};
        int[] array2 = new int[]{2, 1, 2, 5 , 6};
        divide(array, array2);
    }

    public static void divide(int[] a, int[] b) {
        try {
            if (a.length == b.length) {
                for (int i = 0; i < a.length; i++) {
                    int result = a[i] / b[i];
                    System.out.println(result);
                }
            }

        } catch (IndexOutOfBoundsException  | ArithmeticException e) {
            System.out.println("Error");
        }
    }
}
