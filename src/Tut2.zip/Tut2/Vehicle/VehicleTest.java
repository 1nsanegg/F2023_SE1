package Tut2.Vehicle;

public class VehicleTest {
    public static void main(String[] args) {
        IronSuit ironman = new IronSuit();
        ironman.fly("Ha Noi", "Ho Chi Minh", 10);
    }
}
